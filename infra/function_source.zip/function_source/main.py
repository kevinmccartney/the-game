import functions_framework


@functions_framework.http
def hello_http():
    """HTTP ping Cloud Function.
    Args:
    Returns:
        Pong.
    """
    return "Pong"
